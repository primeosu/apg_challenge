<?php 
session_start(); 
error_reporting(0);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php echo $_SESSION["result"]; ?>
        <form action="uploadandfilter.php" method="post" enctype="multipart/form-data">
            <input type="file" name="file" />
            <input type="submit" name="submit" value="Submit" />
        </form>
        
    </body>
</html>
