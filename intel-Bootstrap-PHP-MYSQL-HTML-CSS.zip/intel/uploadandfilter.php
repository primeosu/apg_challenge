<?php
session_start();

require 'inc/dbcon.php';
    
if($_SERVER['REQUEST_METHOD'] == "POST"){

   if($_FILES['file']['tmp_name'] == ""){
        echo "<script>alert('Please Upload CVS File first.')</script>";
        echo "<script>window.location = 'index.php'</script>";
        exit();
    }
    
    $t = date("Y-m-d");
    $s = "_";
    $d = rand(20,360);
    $fileName = $_FILES['file']['name'];
    $fileName = $d.$s.$s.$t.$fileName;
    $tmp_name = $_FILES['file']['tmp_name'];
    $desired_dir = "upload";
    if(is_dir($desired_dir) == false){
       mkdir("$desired_dir", 0700);		// Create directory if it does not exist
    }

    $ext = pathinfo($fileName, PATHINFO_EXTENSION);
    $allowed = array('csv');
    if(!in_array( $ext, $allowed ) ) {
        echo "<script>alert('Please Choose a CSV file.')</script>";
         echo "<script>window.location = 'index.php'</script>";
         die();
    }
    
    $uploadFfile = move_uploaded_file($tmp_name, "upload/".$fileName);
    // Name of your CSV file
    $csv_file = "upload/".$fileName; 

    if (($handle = fopen($csv_file, "r")) !== FALSE) {
       fgetcsv($handle);   
       while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $num = count($data);
            for ($c=0; $c < $num; $c++) {
              $col[$c] = $data[$c];
            }
            $col1 = $col[0];
            $col2 = $col[1];
            $col3 = $col[2];
            $col4 = $col[3];
            $col5 = $col[4];

            // SQL Query to insert data into DataBase
            $query = "INSERT INTO tbl_record VALUES(default, '".$col1."','".$col2."','".$col3."','".$col4."','".$col5."')";
            $s     = mysql_query($query, $connect );
     }
        fclose($handle);
    }else{
        echo "File not opened\n";
    }

    if($s ){
         echo "<script>alert('File data successfully imported to database!!')</script>";
          $tempString = "";
            $query_q = "select count(classificationType) as indentifier, classificationType from tbl_record group by classificationType";
            $result    = mysql_query($query_q, $connect );
            while($rows = mysql_fetch_array($result)){
                $tempString .= $rows['classificationType'] ."  => ". $rows['indentifier'] . " <br />"; 
            }
           $_SESSION["result"] = $tempString;
         echo "<script>window.location = 'index.php'</script>";
    }else{
         echo "<script>alert('Sorry File data not successfully imported to database!!')</script>";
         echo "<script>window.location = 'index.php'</script>";
    }

   mysql_close($connect);
}
?>